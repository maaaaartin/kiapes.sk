<?php /** @var array $sites @var callable $e */ ?>
<!DOCTYPE html>
<html lang="sk">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Administrácia Kiapeš</title>
<link rel="stylesheet" href="/assets/css/base.css">
<link rel="stylesheet" href="/assets/css/components.css">
</head>
<body>
<main class="site-main">
<h1>Weby</h1>
<table>
<caption>Zoznam všetkých webov v systéme</caption>
<thead><tr><th scope="col">Web</th><th scope="col">Host</th><th scope="col">Publikované stránky</th><th scope="col">Stav</th></tr></thead>
<tbody>
<?php foreach ($sites as $site): ?>
<tr>
<td><?= $e($site['name']) ?></td>
<td><a href="https://<?= $e($site['host']) ?>"><?= $e($site['host']) ?></a></td>
<td><?= (int)$site['page_count'] ?></td>
<td><?= $site['is_active'] ? 'Aktívny' : 'Neaktívny' ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<p><a href="/admin?action=logout">Odhlásiť sa</a></p>
</main>
</body>
</html>
