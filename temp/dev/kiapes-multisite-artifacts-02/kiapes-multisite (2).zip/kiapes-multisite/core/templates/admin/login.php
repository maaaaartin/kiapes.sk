<?php /** @var callable $e @var string $csrf @var ?string $error */ ?>
<!DOCTYPE html>
<html lang="sk">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Prihlásenie do administrácie</title>
<link rel="stylesheet" href="/assets/css/base.css">
<link rel="stylesheet" href="/assets/css/components.css">
</head>
<body>
<main class="site-main">
<h1>Prihlásenie</h1>
<?php if ($error): ?><p role="alert"><?= $e($error) ?></p><?php endif; ?>
<form method="post" action="/admin?action=login">
<input type="hidden" name="_csrf" value="<?= $e($csrf) ?>">
<label for="email">E-mail</label>
<input id="email" name="email" type="email" required autocomplete="username">
<label for="password">Heslo</label>
<input id="password" name="password" type="password" required autocomplete="current-password">
<button type="submit">Prihlásiť sa</button>
</form>
</main>
</body>
</html>
