<?php /** @var array $blocks @var callable $e */ ?>
<article class="business-card">
<?php foreach ($blocks as $block): $data=$block['data']; ?>
<?php if ($block['type']==='heading'): ?>
<h1 class="card-name"><?= $e($data['text'] ?? '') ?></h1>
<?php elseif ($block['type']==='richtext'): ?>
<section class="card-section">
<h2><?= $e($data['title'] ?? '') ?></h2>
<p><?= nl2br($e($data['text'] ?? '')) ?></p>
</section>
<?php elseif ($block['type']==='links'): ?>
<ul class="contact-list">
<?php foreach ($data['items'] ?? [] as $item): ?>
<li><span class="label"><?= $e($item['label'] ?? '') ?></span><a href="<?= $e($item['href'] ?? '#') ?>"><?= $e($item['text'] ?? '') ?></a></li>
<?php endforeach; ?>
</ul>
<?php elseif ($block['type']==='contact'): ?>
<ul class="contact-list">
<?php foreach ($data['items'] ?? [] as $item): ?>
<li><span class="label"><?= $e($item['label'] ?? '') ?></span><span><?= $e($item['value'] ?? '') ?></span></li>
<?php endforeach; ?>
</ul>
<?php endif; ?>
<?php endforeach; ?>
</article>
