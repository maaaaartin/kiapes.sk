<?php /** @var array $blocks @var callable $e */ ?>
<div class="home-groups">
<?php foreach ($blocks as $block): ?>
<?php if ($block['type']==='heading'): ?>
<h1 class="family-name"><?= $e($block['data']['text'] ?? '') ?></h1>
<?php elseif ($block['type']==='links'): ?>
<ul class="family-links">
<?php foreach ($block['data']['items'] ?? [] as $item): ?>
<li><a href="<?= $e($item['href'] ?? '#') ?>"><?= $e($item['text'] ?? '') ?></a></li>
<?php endforeach; ?>
</ul>
<?php endif; ?>
<?php endforeach; ?>
</div>
