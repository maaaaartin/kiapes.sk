<?php

declare(strict_types=1);

namespace Kiapes;

final class Application
{
    public function __construct(private array $config) {}
    public static function boot(array $config): self { return new self($config); }

    public function run(): void
    {
        $host = strtolower($_SERVER['HTTP_HOST'] ?? '');
        $host = preg_replace('/^www\./', '', $host);
        $host = rtrim($host, '.');
        if (!isset($this->config['sites'][$host])) {
            http_response_code(404);
            echo 'Web nebol nájdený.';
            return;
        }
        $slug = $this->config['sites'][$host];
        if (str_starts_with($_SERVER['REQUEST_URI'] ?? '/', '/admin')) {
            (new AdminController($this->config))->handle();
            return;
        }
        (new SiteController($this->config))->handle($host, $slug);
    }
}
