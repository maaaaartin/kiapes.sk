<?php

declare(strict_types=1);

namespace Kiapes;

final class SiteController
{
    public function __construct(private array $config) {}

    public function handle(string $host, string $slug): void
    {
        $pdo = Db::connection();
        $site = $this->fetchSite($pdo, $slug);
        if (!$site) { http_response_code(404); echo 'Web nebol nájdený.'; return; }

        $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/', '/');
        $page = $this->fetchPage($pdo, (int)$site['id'], $path);

        if (!$page) {
            http_response_code(404);
            $page = $this->fetchPage($pdo, (int)$site['id'], '');
        }
        if (!$page) { http_response_code(404); echo 'Stránka neexistuje.'; return; }

        $blocks = $this->fetchBlocks($pdo, (int)$page['id']);
        $menu = $this->fetchMenu($pdo, (int)$site['id']);
        $this->render($site, $page, $blocks, $menu);
    }

    private function fetchSite(PDO $pdo, string $slug): ?array
    {
        $s = $pdo->prepare('SELECT * FROM sites WHERE slug=? AND is_active=1 LIMIT 1');
        $s->execute([$slug]);
        return $s->fetch() ?: null;
    }

    private function fetchPage(PDO $pdo, int $siteId, string $path): ?array
    {
        $slug = $path === '' ? 'home' : $path;
        $s = $pdo->prepare('SELECT * FROM pages WHERE site_id=? AND status="published" AND (slug=? OR slug=?) ORDER BY CASE WHEN slug=? THEN 0 ELSE 1 END LIMIT 1');
        $s->execute([$siteId,$slug,$path,$slug]);
        return $s->fetch() ?: null;
    }

    private function fetchBlocks(PDO $pdo, int $pageId): array
    {
        $s = $pdo->prepare('SELECT * FROM blocks WHERE page_id=? ORDER BY sort_order');
        $s->execute([$pageId]);
        return array_map(fn($r)=>['id'=>$r['id'],'type'=>$r['type'],'sort_order'=>$r['sort_order'],'data'=>json_decode($r['data'],true) ?: []], $s->fetchAll());
    }

    private function fetchMenu(PDO $pdo, int $siteId): array
    {
        $s = $pdo->prepare('SELECT * FROM menu_items WHERE site_id=? ORDER BY sort_order');
        $s->execute([$siteId]);
        return $s->fetchAll();
    }

    private function render(array $site, array $page, array $blocks, array $menu): void
    {
        $e = fn(?string $v): string => htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8');
        $title = $e($page['title']);
        $description = $e($page['meta_description'] ?: $site['name']);
        $lang = $e($site['lang']);
        header('Content-Type: text/html; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        require dirname(__DIR__) . '/templates/layout.php';
    }
}
